#ifndef BINARYTREE
#define BINARYTREE
#include "BinaryTree.h"
#endif

BinaryTree::BinaryTree()
{
	//empty constructor
}