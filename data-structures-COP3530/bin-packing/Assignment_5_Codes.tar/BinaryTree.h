#ifndef BINARYTREENODE
#define BINARYTREENODE
#include "BinaryTreeNode.h"
#endif

class BinaryTree{
	public:
		BinaryTree();

	protected:
		BinaryTreeNode* root;
		int treeSize;
};